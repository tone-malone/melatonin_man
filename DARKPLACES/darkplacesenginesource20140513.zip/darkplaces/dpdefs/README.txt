Yet incomplete collected definition files for the DP extensions etc.

TODO:
- make sure only fields/globals that DP actually uses are in the defs files
- make sure all builtins of DP are mentioned (by script)
