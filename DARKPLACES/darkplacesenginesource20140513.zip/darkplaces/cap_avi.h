void SCR_CaptureVideo_Avi_BeginVideo(void);
